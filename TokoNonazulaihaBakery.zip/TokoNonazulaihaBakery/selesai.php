<?php 
	include 'header.php';
 ?>

<div class="container" style="padding-bottom: 300px;">
	<h2 class="bg-success text-center" style="padding: 10px;">Checkout Berhasil</h2>
	<h4 class="text-center" style="font-weight: bold;">Terimakasih Sudah Berbelanja di  Nonazulaiha bakery, Pesananmu sedang diproses silahkan tunggu barangmu dirumah ya.. :)</h4>
	
	<p class="text-center mt-4">
    Ada pertanyaan? Hubungi kami di 
    <a href="https://wa.me/6288224754852" target="_blank" style="font-weight: bold; color: green;">
        0882-2475-4852 (Chat via WhatsApp)
    </a>
</p>




 <?php 
	include 'footer.php';
 ?>