<?php 
include '../../koneksi/koneksi.php';

// Ambil data dari form POST
$kode    = $_POST['kd_material'];
$nama    = $_POST['nama'];
$stok    = $_POST['stok'];
$satuan  = $_POST['satuan'];
$harga   = $_POST['harga'];
$tanggal = date("Y-m-d"); // Gunakan "Y" (bukan "y") untuk tahun 4 digit

// Lakukan update data
$query = "UPDATE inventory 
          SET nama = '$nama', 
              qty = '$stok', 
              satuan = '$satuan', 
              harga = '$harga', 
              tanggal = '$tanggal' 
          WHERE kode_bk = '$kode'";

$result = mysqli_query($conn, $query);

// Cek apakah berhasil
if($result){
    echo "
    <script>
        alert('DATA BERHASIL DIUPDATE');
        window.location = '../inventory.php';
    </script>
    ";
} else {
    echo "
    <script>
        alert('GAGAL UPDATE: " . mysqli_error($conn) . "');
        window.history.back();
    </script>
    ";
}
?>
