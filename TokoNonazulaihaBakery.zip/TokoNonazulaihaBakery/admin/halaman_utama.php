<?php 
include 'header.php';

$result1 = mysqli_query($conn, "SELECT DISTINCT invoice FROM produksi WHERE terima = 0 AND tolak = 0");
$jml1 = mysqli_num_rows($result1);

$result2 = mysqli_query($conn, "SELECT DISTINCT invoice FROM produksi WHERE tolak = 1");
$jml2 = mysqli_num_rows($result2);

$result3 = mysqli_query($conn, "SELECT DISTINCT invoice FROM produksi WHERE terima = 1");
$jml3 = mysqli_num_rows($result3);
?>

<div class="container" style="margin-top: 30px;">
    <div class="row">
        <!-- PESANAN BARU -->
        <div class="col-md-4">
            <div class="panel panel-warning">
                <div class="panel-heading text-center">
                    <h4><strong>PESANAN BARU</strong></h4>
                </div>
                <div class="panel-body text-center">
                    <h1 style="font-size: 60px;"><strong><?= $jml1; ?></strong></h1>
                </div>
            </div>
        </div>

        <!-- PESANAN DIBATALKAN -->
        <div class="col-md-4">
            <div class="panel panel-danger">
                <div class="panel-heading text-center">
                    <h4><strong>PESANAN DIBATALKAN</strong></h4>
                </div>
                <div class="panel-body text-center">
                    <h1 style="font-size: 60px;"><strong><?= $jml2; ?></strong></h1>
                </div>
            </div>
        </div>

        <!-- PESANAN DITERIMA -->
        <div class="col-md-4">
            <div class="panel panel-success">
                <div class="panel-heading text-center">
                    <h4><strong>PESANAN DITERIMA</strong></h4>
                </div>
                <div class="panel-body text-center">
                    <h1 style="font-size: 60px;"><strong><?= $jml3; ?></strong></h1>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
