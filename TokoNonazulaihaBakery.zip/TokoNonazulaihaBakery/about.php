<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ff8680"><b>Tentang Kami</b></h2>
	<p class="text-justify">Toko Nonazulaiha Bakery merupakan usaha yang bergerak di bidang produksi dan penjualan berbagai jenis roti dan kue. Berdiri sejak tahun 2023, toko ini berkomitmen untuk menyediakan produk-produk berkualitas tinggi yang diolah dengan standar kebersihan dan cita rasa yang terjamin.

Seiring dengan perkembangan teknologi dan meningkatnya kebutuhan masyarakat akan kemudahan dalam melakukan transaksi secara daring, Toko Nonazulaiha Bakery mengembangkan Sistem Informasi Penjualan dan Laporan Otomatis Berbasis Web.Sistem ini dirancang untuk mendukung proses penjualan secara efisien dan memberikan kemudahan akses informasi bagi pelanggan maupun pengelola toko.

Melalui sistem ini, pelanggan dapat melihat daftar produk, melakukan pemesanan secara online, serta melakukan pembayaran dengan lebih praktis. </p>

