<?php 
$conn = mysqli_connect("localhost", "root", "", "Toko_Nonazulaiha_bakery");
 ?>
