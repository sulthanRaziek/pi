<footer style="background-color: gray;padding: 1px;" class="print">
</footer>
</body>
</html>