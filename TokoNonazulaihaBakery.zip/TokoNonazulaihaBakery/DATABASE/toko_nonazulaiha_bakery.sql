-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2025 at 05:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_nonazulaiha_bakery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626');

-- --------------------------------------------------------

--
-- Table structure for table `bom_produk`
--

CREATE TABLE `bom_produk` (
  `kode_bom` varchar(100) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `kebutuhan` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bom_produk`
--

INSERT INTO `bom_produk` (`kode_bom`, `kode_bk`, `kode_produk`, `nama_produk`, `kebutuhan`) VALUES
('B0001', 'M0002', 'P0001', 'Roti Sobek', '2'),
('B0001', 'M0001', 'P0001', 'Roti Sobek', '4'),
('B0001', 'M0004', 'P0001', 'Roti Sobek', '3'),
('B0002', 'M0001', 'P0002', 'Maryam', '4'),
('B0002', 'M0004', 'P0002', 'Maryam', '3'),
('B0002', 'M0003', 'P0002', 'Maryam', '2'),
('B0003', 'M0002', 'P0003', 'Kue tart coklat', '2'),
('B0003', 'M0003', 'P0003', 'Kue tart coklat', '5'),
('B0003', 'M0005', 'P0003', 'Kue tart coklat', '5'),
('B0004', 'M0001', 'P0004', 'nastar nanas', '300'),
('B0004', 'M0007', 'P0004', 'nastar nanas', '90'),
('B0004', 'M0008', 'P0004', 'nastar nanas', '350'),
('B0004', 'M0009', 'P0004', 'nastar nanas', '100'),
('B0004', 'M0004', 'P0004', 'nastar nanas', '50'),
('B0001', 'M0002', 'P0001', 'Roti Sobek', '2'),
('B0005', 'M0001', 'P0005', 'Bolu coklat panggang', '300'),
('B0005', 'M0005', 'P0005', 'Bolu coklat panggang', '19'),
('B0005', 'M0010', 'P0005', 'Bolu coklat panggang', '200'),
('B0005', 'M0007', 'P0005', 'Bolu coklat panggang', '25'),
('B0005', 'M0006', 'P0005', 'Bolu coklat panggang', '200'),
('B0005', 'M0009', 'P0005', 'Bolu coklat panggang', '2'),
('B0001', 'M0001', 'P0001', 'Roti Sobek', '4'),
('B0001', 'M0004', 'P0001', 'Roti Sobek', '3'),
('B0002', 'M0001', 'P0002', 'Maryam', '4'),
('B0002', 'M0004', 'P0002', 'Maryam', '3'),
('B0002', 'M0003', 'P0002', 'Maryam', '2'),
('B0003', 'M0002', 'P0003', 'Kue tart coklat', '2'),
('B0003', 'M0003', 'P0003', 'Kue tart coklat', '5'),
('B0003', 'M0005', 'P0003', 'Kue tart coklat', '5');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `kode_customer` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`kode_customer`, `nama`, `email`, `username`, `password`, `telp`) VALUES
('C0001', 'tan', 'tan@gmail.com', 'tan', '$2y$10$H6P97bNmEwKlMuh0QnaRb.5BKIrtP/VBqf.YB7ozqlXyyuxWTHFx6', '0888241321212'),
('C0002', 'torang', 'situmorang2110@gmail.com', 'torang', '$2y$10$ap2x7NHP8nT9fp48aqe1QeHhm/nI.VCSuT10.f6fAHNynlONthYWm', '0888142542121');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `kode_bk` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `satuan` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`kode_bk`, `nama`, `qty`, `satuan`, `harga`, `tanggal`) VALUES
('M0001', 'Tepung', '-1656', 'Kg', 100, '2025-06-17'),
('M0002', 'Pengembang', '4970', 'Kg', 100, '2025-06-17'),
('M0003', 'Cream', '4972', 'Kg', 300, '2025-06-17'),
('M0004', 'Keju', '4855', 'Kg', 400, '2025-06-17'),
('M0005', 'Coklat', '645', 'Kg', 500, '2025-04-11'),
('M0006', 'Gula', '-500', 'gram', 450, '2025-06-17'),
('M0007', 'Mentega', '4670', ' gram', 800, '2025-06-17'),
('M0008', 'Nanas', '6300', 'kg', 80, '2025-06-17'),
('M0009', 'Tepung maizena ', '1788', 'gram', 800, '2025-06-17'),
('M0010', 'Telur ayam', '300', 'gram', 100, '2025-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `kode_customer` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`) VALUES
(16, 'C0003', 'P0002', 'Maryam', 5, 15000),
(17, 'C0003', 'P0003', 'Kue tart coklat', 2, 100000);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `kode_produk` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`kode_produk`, `nama`, `image`, `deskripsi`, `harga`) VALUES
('P0001', 'Roti Sobek', '67fe7bd932d86.jpg', '								Roti sobek merupakan produk olahan yang hasil proses pemanggangan adonan yang telah difermentasi\r\n																														', 10000),
('P0002', 'Roti Maryam', '67fe7ccfa22ae.jpg', '															roti pipih (flatbread) yang populer di Indonesia, Malaysia, dan negara-negara Asia Tenggara lainnya, dengan pengaruh India.									', 15000),
('P0003', 'Kue tart coklat', '68025811dfcb9.jpg', '												Tart adalah kue kering panggang yang terbuat dari adonan kue berwarna cokelat keemasan dan isian\r\n												', 100000),
('P0004', 'Nastar nanas', '6802581c71580.jpg', '																																				Nastar nanas adalah kue kering khas Lebaran yang berbentuk bulat dengan isian selai nanas di tengahnya, memiliki rasa manis, gurih, dan aroma butter yang khas. \r\n																														', 54000),
('P0005', 'Bolu coklat panggang', '68501d9a16529.png', '												Bolu coklat panggang adalah kue bolu yang memiliki rasa coklat yang kaya dan tekstur yang lembut namun padat.\r\n												', 85000);

-- --------------------------------------------------------

--
-- Table structure for table `produksi`
--

CREATE TABLE `produksi` (
  `id_order` int(11) NOT NULL,
  `invoice` varchar(200) NOT NULL,
  `kode_customer` varchar(200) NOT NULL,
  `kode_produk` varchar(200) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `provinsi` varchar(200) NOT NULL,
  `kota` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kode_pos` varchar(200) NOT NULL,
  `terima` varchar(200) NOT NULL,
  `tolak` varchar(200) NOT NULL,
  `cek` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produksi`
--

INSERT INTO `produksi` (`id_order`, `invoice`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`, `status`, `tanggal`, `provinsi`, `kota`, `alamat`, `kode_pos`, `terima`, `tolak`, `cek`) VALUES
(8, 'INV0001', 'C0002', 'P0003', 'Kue tart coklat', 1, 100000, 'Pesanan Baru', '2020-07-26 17:00:00', 'Jawa Timur', 'Surabaya', 'Jl.Tanah Merah Indah 1', '60129', '2', '1', 0),
(9, 'INV0002', 'C0002', 'P0001', 'Roti Sobek', 3, 10000, '0', '2025-06-17 16:46:01', 'Jawa Barat', 'Bandung', 'Jl.Jati Nangor Blok C, 10', '30712', '1', '0', 1),
(10, 'INV0003', 'C0003', 'P0002', 'Maryam', 2, 15000, '0', '2025-06-17 16:46:01', 'Jawa Tengah', 'Yogyakarta', 'Jl.Malioboro, Blok A 10D', '30123', '1', '0', 1),
(11, 'INV0003', 'C0003', 'P0003', 'Kue tart coklat', 1, 100000, '0', '2025-06-17 16:46:01', 'Jawa Tengah', 'Yogyakarta', 'Jl.Malioboro, Blok A 10D', '30123', '1', '0', 1),
(12, 'INV0003', 'C0003', 'P0001', 'Roti Sobek', 1, 10000, '0', '2025-06-17 16:46:01', 'Jawa Tengah', 'Yogyakarta', 'Jl.Malioboro, Blok A 10D', '30123', '1', '0', 1),
(13, 'INV0004', 'C0004', 'P0002', 'Maryam', 1, 15000, '0', '2025-06-17 16:46:01', 'Jawa Timur', 'Sidoarjo', 'Jl.KH Syukur Blok C 18 A', '50987', '1', '0', 1),
(14, 'INV0005', 'C0005', 'P0001', 'Roti Sobek', 1, 10000, '0', '2025-06-17 16:46:01', 'Bekasi', 'tambun', 'Jl.monas', '14212', '1', '0', 1),
(15, 'INV0005', 'C0005', 'P0002', 'Maryam', 1, 15000, '0', '2025-06-17 16:46:01', 'Bekasi', 'tambun', 'Jl.monas', '14212', '1', '0', 1),
(16, 'INV0006', 'C0006', 'P0003', 'Kue tart coklat', 1, 100000, '0', '2025-06-17 12:27:14', 'jawa barat', 'bekasi', 'jl.wibu', '12121', '1', '0', 0),
(17, 'INV0006', 'C0006', 'P0001', 'Roti Sobek', 1, 10000, '0', '2025-06-17 12:27:14', 'jawa barat', 'bekasi', 'jl.wibu', '12121', '1', '0', 0),
(18, 'INV0007', 'C0005', 'P0004', 'Nastar nanas', 1, 54000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'Jl.antara dalam ', '12141', '1', '0', 1),
(19, 'INV0007', 'C0005', 'P0005', 'Bolu coklat panggang', 1, 85000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'Jl.antara dalam ', '12141', '1', '0', 1),
(20, 'INV0008', 'C0005', 'P0005', 'Bolu coklat panggang', 1, 85000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12121', '1', '0', 1),
(21, 'INV0008', 'C0005', 'P0004', 'Nastar nanas', 1, 54000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12121', '1', '0', 1),
(22, 'INV0009', 'C0005', 'P0001', 'Roti Sobek', 1, 10000, 'Pesanan Baru', '0000-00-00 00:00:00', 'jawa barat', 'bekasi', 'jl.anta', '12122', '2', '1', 0),
(23, 'INV0010', 'C0005', 'P0004', 'Nastar nanas', 1, 54000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi1', 'jl.antqra', '1212', '1', '0', 1),
(24, 'INV0010', 'C0005', 'P0005', 'Bolu coklat panggang', 1, 85000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi1', 'jl.antqra', '1212', '1', '0', 1),
(25, 'INV0011', 'C0005', 'P0002', 'Roti Maryam', 1, 15000, 'Pesanan Baru', '0000-00-00 00:00:00', '', 'zdvdv', 'dvzxvsd', '324324', '2', '1', 0),
(26, 'INV0012', 'C0007', 'P0001', 'Roti Sobek', 1, 10000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl,antara', '12111', '1', '0', 1),
(27, 'INV0012', 'C0007', 'P0002', 'Roti Maryam', 1, 15000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl,antara', '12111', '1', '0', 1),
(28, 'INV0012', 'C0007', 'P0003', 'Kue tart coklat', 1, 100000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl,antara', '12111', '1', '0', 1),
(29, 'INV0012', 'C0007', 'P0004', 'Nastar nanas', 1, 54000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl,antara', '12111', '1', '0', 1),
(30, 'INV0012', 'C0007', 'P0005', 'Bolu coklat panggang', 1, 85000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl,antara', '12111', '1', '0', 1),
(31, 'INV0013', 'C0007', 'P0001', 'Roti Sobek', 35, 10000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '121222', '1', '0', 1),
(32, 'INV0013', 'C0007', 'P0002', 'Roti Maryam', 40, 15000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '121222', '1', '0', 1),
(33, 'INV0013', 'C0007', 'P0003', 'Kue tart coklat', 4, 100000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '121222', '1', '0', 1),
(34, 'INV0013', 'C0007', 'P0005', 'Bolu coklat panggang', 3, 85000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '121222', '1', '0', 1),
(35, 'INV0014', 'C0001', 'P0001', 'Roti Sobek', 30, 10000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12122', '1', '0', 1),
(36, 'INV0014', 'C0001', 'P0002', 'Roti Maryam', 5, 15000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12122', '1', '0', 1),
(37, 'INV0014', 'C0001', 'P0003', 'Kue tart coklat', 5, 100000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12122', '1', '0', 1),
(38, 'INV0014', 'C0001', 'P0004', 'Nastar nanas', 20, 54000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12122', '1', '0', 1),
(39, 'INV0014', 'C0001', 'P0005', 'Bolu coklat panggang', 5, 85000, '0', '2025-06-17 16:46:01', 'jawa barat', 'bekasi', 'jl.antara', '12122', '1', '0', 1),
(40, 'INV0015', 'C0001', 'P0001', 'Roti Sobek', 5, 10000, 'Pesanan Baru', '2025-06-17 12:27:14', 'Kota Bekasi/Pondok Gede', 'Kota Bekasi/Pondok Gede', 'Jl.antara dalam bukit kemang indah no.17', '17413', '2', '1', 0),
(41, 'INV0016', 'C0001', 'P0002', 'Roti Maryam', 1, 15000, 'Pesanan Baru', '2025-06-17 12:27:14', 'Kota Bekasi/Pondok Gede', 'Kota Bekasi/Pondok Gede', 'Jl.antara dalam bukit kemang indah no.17', '17413', '2', '1', 0),
(42, 'INV0017', 'C0001', 'P0002', 'Roti Maryam', 1, 15000, 'Pesanan Baru', '2025-06-17 12:27:14', '', '', '', '', '2', '1', 0),
(43, 'INV0018', 'C0001', 'P0002', 'Roti Maryam', 1, 15000, 'Pesanan Baru', '2025-06-17 12:27:14', '', '', '', '', '2', '1', 0),
(44, 'INV0019', 'C0001', 'P0001', 'Roti Sobek', 1, 10000, 'Pesanan Baru', '2025-06-17 12:27:14', '', '', '', '', '2', '1', 0),
(45, 'INV0020', 'C0001', 'P0001', 'Roti Sobek', 1, 10000, 'Pesanan Baru', '2025-06-17 12:27:14', 'Kota Bekasi/Pondok Gede', 'Kota Bekasi/Pondok Gede', 'Jl.antara dalam bukit kemang indah no.17', '17413', '2', '1', 0),
(46, 'INV0021', 'C0001', 'P0005', 'Bolu coklat panggang', 1, 85000, '0', '2025-06-17 16:46:01', 'sultan@123', '', 'sukabumi', '0821112124212', '1', '0', 1),
(47, 'INV0021', 'C0001', 'P0001', 'Roti Sobek', 1, 10000, '0', '2025-06-17 16:46:01', 'sultan@123', '', 'sukabumi', '0821112124212', '1', '0', 1),
(48, 'INV0022', 'C0001', 'P0001', 'Roti Sobek', 3, 10000, '0', '2025-06-17 16:46:01', 'sultan@123', '', 'as', '21234', '1', '0', 1),
(49, 'INV0022', 'C0001', 'P0005', 'Bolu coklat panggang', 3, 85000, '0', '2025-06-17 16:46:01', 'sultan@123', '', 'as', '21234', '1', '0', 1),
(50, 'INV0023', 'C0001', 'P0001', 'Roti Sobek', 2, 10000, '0', '2025-06-23 13:38:54', 'sultan@123', '', 'Jl.antara dalam bukit kemang indah no.17', '082114510108', '1', '0', 1),
(51, 'INV0023', 'C0001', 'P0002', 'Roti Maryam', 2, 15000, '0', '2025-06-23 13:38:54', 'sultan@123', '', 'Jl.antara dalam bukit kemang indah no.17', '082114510108', '1', '0', 1),
(52, 'INV0023', 'C0001', 'P0003', 'Kue tart coklat', 2, 100000, '0', '2025-06-23 13:38:54', 'sultan@123', '', 'Jl.antara dalam bukit kemang indah no.17', '082114510108', '1', '0', 1),
(53, 'INV0023', 'C0001', 'P0004', 'Nastar nanas', 2, 54000, '0', '2025-06-23 13:38:54', 'sultan@123', '', 'Jl.antara dalam bukit kemang indah no.17', '082114510108', '1', '0', 1),
(54, 'INV0023', 'C0001', 'P0005', 'Bolu coklat panggang', 2, 85000, '0', '2025-06-23 13:38:54', 'sultan@123', '', 'Jl.antara dalam bukit kemang indah no.17', '082114510108', '1', '0', 1),
(55, 'INV0024', 'C0001', 'P0001', 'Roti Sobek', 1, 10000, 'Pesanan Baru', '2025-06-23 13:39:53', 'sultan@123', '', 'Jl.antara dalam bukit kemang indah no.17', '082114510108', '2', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `report_cancel`
--

CREATE TABLE `report_cancel` (
  `id_report_cancel` int(11) NOT NULL,
  `id_order` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_inventory`
--

CREATE TABLE `report_inventory` (
  `id_report_inv` int(11) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `nama_bahanbaku` varchar(100) NOT NULL,
  `jml_stok_bk` int(11) NOT NULL,
  `tanggal` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_omset`
--

CREATE TABLE `report_omset` (
  `id_report_omset` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_omset` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report _penjualan`
--

CREATE TABLE `report _penjualan` (
  `id_report_sell` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_terjual` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_produksi`
--

CREATE TABLE `report_produksi` (
  `id_report_prd` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_profit`
--

CREATE TABLE `report_profit` (
  `id_report_profit` int(11) NOT NULL,
  `kode_bom` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `jumlah` varchar(11) NOT NULL,
  `total_profit` varchar(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`kode_bk`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indexes for table `produksi`
--
ALTER TABLE `produksi`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `report_cancel`
--
ALTER TABLE `report_cancel`
  ADD PRIMARY KEY (`id_report_cancel`);

--
-- Indexes for table `report_inventory`
--
ALTER TABLE `report_inventory`
  ADD PRIMARY KEY (`id_report_inv`);

--
-- Indexes for table `report_omset`
--
ALTER TABLE `report_omset`
  ADD PRIMARY KEY (`id_report_omset`);

--
-- Indexes for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  ADD PRIMARY KEY (`id_report_sell`);

--
-- Indexes for table `report_produksi`
--
ALTER TABLE `report_produksi`
  ADD PRIMARY KEY (`id_report_prd`);

--
-- Indexes for table `report_profit`
--
ALTER TABLE `report_profit`
  ADD PRIMARY KEY (`id_report_profit`),
  ADD UNIQUE KEY `kode_bom` (`kode_bom`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `produksi`
--
ALTER TABLE `produksi`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `report_cancel`
--
ALTER TABLE `report_cancel`
  MODIFY `id_report_cancel` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_inventory`
--
ALTER TABLE `report_inventory`
  MODIFY `id_report_inv` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_omset`
--
ALTER TABLE `report_omset`
  MODIFY `id_report_omset` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  MODIFY `id_report_sell` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_produksi`
--
ALTER TABLE `report_produksi`
  MODIFY `id_report_prd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_profit`
--
ALTER TABLE `report_profit`
  MODIFY `id_report_profit` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
