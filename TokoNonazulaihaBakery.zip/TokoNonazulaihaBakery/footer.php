<footer style="border-top: 4px solid #ff8680;">
    <div class="container" style="padding-bottom: 50px;">
        <div class="row">
            <div class="col-md-4 px-3">		
						<h3 style="color: #ff8680;"><b>Nonazulaiha bakery</b></h3>
						<p>Jl. Antara Dalam Cluster Bukit Kemang Indah No.17</p>
						<p>
							<i class="glyphicon glyphicon-earphone"></i>
							<a href="https://wa.me/628824754852" target="_blank" style="color: #000;">
								+628824754852 (Chat WhatsApp)
							</a>
						</p>
						<p><i class="glyphicon glyphicon-envelope"></i> Nonazulaiha@gmail.com</p>
            </div>

           <div class="col-md-4 pull-right text-right" style="padding: 0 15px;">
						<h5><b>Menu</b></h5>
						<p><a href="#" style="color: #000;">Produk</a></p>
						<p><a href="#" style="color: #000;">Tentang kami</a></p>
						<p><a href="#" style="color: #000;">Manual Aplikasi</a></p>
			</div>

            <div class="col-md-4 px-3">
                <!-- Tambahkan konten lain di sini jika perlu -->
            </div>
        </div>
    </div>
</footer>
